#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=MCU_PIC_Drivers_Revision.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/MCU_PIC_Drivers_Revision.X.production.hex
